import React, { useState, useRef, useEffect, useCallback } from 'react';
import { CameraMode, ZoomLevel, AspectRatio, FlashMode, TimerDuration, FilterType, PortraitEffect, CapturedMedia, CameraSettings, CameraXTelemetry } from './types/camera';
import { CameraViewfinder } from './components/CameraViewfinder';
import { ModeSelector } from './components/ModeSelector';
import { ShutterControls } from './components/ShutterControls';
import { TopBar } from './components/TopBar';
import { GalleryModal } from './components/GalleryModal';
import { SettingsModal } from './components/SettingsModal';
import { CameraXInspector } from './components/CameraXInspector';
import { cameraAudio } from './utils/audioEffects';

// Default initial settings
const DEFAULT_SETTINGS: CameraSettings = {
  sceneOptimizer: true,
  scanQrCodes: true,
  gridLines: false,
  watermark: false,
  watermarkText: 'Galaxy S24 Ultra · CameraX',
  shutterSound: true,
  highEfficiencyVideo: false,
  zeroShutterLag: true,
  swipeShutterAction: 'burst',
  stabilization: true,
};

// Initial preloaded gallery items
const INITIAL_GALLERY: CapturedMedia[] = [
  {
    id: 'shot_init_1',
    type: 'photo',
    url: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=1200&q=80',
    thumbnailUrl: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=200&q=80',
    timestamp: Date.now() - 1000 * 60 * 35,
    metadata: {
      width: 4000,
      height: 3000,
      mode: 'portrait',
      zoom: 1,
      flash: 'off',
      filter: 'original',
      iso: 64,
      shutterSpeed: '1/250s',
      focalLength: '24mm f/1.7',
      lensFacing: 'back',
      aspectRatio: '3:4',
    },
  },
  {
    id: 'shot_init_2',
    type: 'photo',
    url: 'https://images.unsplash.com/photo-1506744038136-46273834b3fb?auto=format&fit=crop&w=1200&q=80',
    thumbnailUrl: 'https://images.unsplash.com/photo-1506744038136-46273834b3fb?auto=format&fit=crop&w=200&q=80',
    timestamp: Date.now() - 1000 * 60 * 120,
    metadata: {
      width: 4000,
      height: 3000,
      mode: 'photo',
      zoom: 0.6,
      flash: 'off',
      filter: 'warm',
      iso: 50,
      shutterSpeed: '1/500s',
      focalLength: '13mm f/2.2',
      lensFacing: 'back',
      aspectRatio: '3:4',
    },
  },
];

export default function App() {
  // Main Camera State
  const [mode, setMode] = useState<CameraMode>('photo');
  const [zoom, setZoom] = useState<ZoomLevel>(1);
  const [aspectRatio, setAspectRatio] = useState<AspectRatio>('3:4');
  const [flash, setFlash] = useState<FlashMode>('off');
  const [timerDuration, setTimerDuration] = useState<TimerDuration>(0);
  const [filter, setFilter] = useState<FilterType>('original');
  const [portraitEffect, setPortraitEffect] = useState<PortraitEffect>('natural');
  const [portraitBlur, setPortraitBlur] = useState<number>(4);
  const [facingMode, setFacingMode] = useState<'back' | 'front'>('back');
  const [motionPhoto, setMotionPhoto] = useState<boolean>(false);

  // Video Recording State
  const [isRecording, setIsRecording] = useState<boolean>(false);
  const [isPaused, setIsPaused] = useState<boolean>(false);
  const [recordingSeconds, setRecordingSeconds] = useState<number>(0);
  const recordIntervalRef = useRef<number | null>(null);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const recordedChunksRef = useRef<Blob[]>([]);

  // Capture Flash & Self Timer Animation
  const [isShutterFlashing, setIsShutterFlashing] = useState<boolean>(false);
  const [countdownRemaining, setCountdownRemaining] = useState<number | null>(null);

  // Gallery & Media
  const [mediaList, setMediaList] = useState<CapturedMedia[]>(INITIAL_GALLERY);
  const [isGalleryOpen, setIsGalleryOpen] = useState<boolean>(false);

  // Modals & Drawers
  const [isSettingsOpen, setIsSettingsOpen] = useState<boolean>(false);
  const [isInspectorOpen, setIsInspectorOpen] = useState<boolean>(false);
  const [settings, setSettings] = useState<CameraSettings>(DEFAULT_SETTINGS);

  // Video element reference from viewfinder
  const videoElRef = useRef<HTMLVideoElement | null>(null);

  // CameraX Telemetry State
  const [telemetry, setTelemetry] = useState<CameraXTelemetry>({
    targetAspectRatio: 'RATIO_4_3',
    resolution: '4000 × 3000 (12MP binning)',
    lensFacing: 'LENS_FACING_BACK',
    flashMode: 'FLASH_MODE_OFF',
    torchState: 'TORCH_OFF',
    zoomRatio: 1.0,
    minZoomRatio: 0.6,
    maxZoomRatio: 30.0,
    previewState: 'STREAMING',
    activeUseCases: ['Preview', 'ImageCapture', 'ImageAnalysis'],
    fps: 60,
  });

  // Update telemetry when controls change
  useEffect(() => {
    setTelemetry({
      targetAspectRatio: aspectRatio === '9:16' ? 'RATIO_16_9' : 'RATIO_4_3',
      resolution: mode === 'video' ? '1920 × 1080 (FHD 60fps)' : '4000 × 3000 (12MP)',
      lensFacing: facingMode === 'back' ? 'LENS_FACING_BACK' : 'LENS_FACING_FRONT',
      flashMode: flash === 'off' ? 'FLASH_MODE_OFF' : flash === 'auto' ? 'FLASH_MODE_AUTO' : 'FLASH_MODE_ON',
      torchState: flash === 'torch' ? 'TORCH_ON' : 'TORCH_OFF',
      zoomRatio: zoom,
      minZoomRatio: 0.6,
      maxZoomRatio: 30.0,
      previewState: 'STREAMING',
      activeUseCases: mode === 'video' ? ['Preview', 'VideoCapture'] : ['Preview', 'ImageCapture'],
      fps: 60,
    });
  }, [aspectRatio, mode, facingMode, flash, zoom]);

  // Handle Shutter Trigger
  const handleShutterTrigger = () => {
    if (timerDuration > 0 && countdownRemaining === null) {
      // Start Countdown Timer
      startCountdown(timerDuration);
      return;
    }

    if (mode === 'video') {
      if (isRecording) {
        stopVideoRecording();
      } else {
        startVideoRecording();
      }
    } else {
      executePhotoCapture();
    }
  };

  // Self Timer Countdown
  const startCountdown = (secs: number) => {
    let count = secs;
    setCountdownRemaining(count);
    cameraAudio.playTimerBeep(false);

    const interval = window.setInterval(() => {
      count -= 1;
      if (count > 0) {
        setCountdownRemaining(count);
        cameraAudio.playTimerBeep(false);
      } else {
        window.clearInterval(interval);
        setCountdownRemaining(null);
        cameraAudio.playTimerBeep(true);
        if (mode === 'video') {
          startVideoRecording();
        } else {
          executePhotoCapture();
        }
      }
    }, 1000);
  };

  // Execute Photo Capture
  const executePhotoCapture = () => {
    cameraAudio.triggerHaptic('heavy');
    cameraAudio.playShutterSound();

    // Trigger white flash animation
    setIsShutterFlashing(true);
    setTimeout(() => setIsShutterFlashing(false), 120);

    // Capture frame from video or fallback canvas
    let dataUrl: string;
    const video = videoElRef.current;

    if (video && video.readyState >= 2 && video.videoWidth > 0) {
      const canvas = document.createElement('canvas');
      canvas.width = video.videoWidth;
      canvas.height = video.videoHeight;
      const ctx = canvas.getContext('2d');
      if (ctx) {
        if (facingMode === 'front') {
          ctx.translate(canvas.width, 0);
          ctx.scale(-1, 1);
        }
        // Apply filter styling to canvas
        if (filter === 'warm') {
          ctx.filter = 'sepia(0.25) saturate(1.2)';
        } else if (filter === 'cool') {
          ctx.filter = 'hue-rotate(15deg) saturate(1.1)';
        } else if (filter === 'mono') {
          ctx.filter = 'grayscale(1) contrast(1.2)';
        } else if (filter === 'vivid') {
          ctx.filter = 'saturate(1.5) contrast(1.15)';
        } else if (filter === 'film') {
          ctx.filter = 'contrast(0.95) brightness(1.05) saturate(1.15)';
        } else if (filter === 'vintage') {
          ctx.filter = 'sepia(0.5) contrast(1.1)';
        } else if (filter === 'noir') {
          ctx.filter = 'grayscale(1) contrast(1.5)';
        }

        ctx.drawImage(video, 0, 0, canvas.width, canvas.height);

        // Watermark if enabled in settings
        if (settings.watermark) {
          ctx.font = 'bold 24px Plus Jakarta Sans, sans-serif';
          ctx.fillStyle = 'rgba(255, 255, 255, 0.85)';
          ctx.shadowColor = 'rgba(0, 0, 0, 0.8)';
          ctx.shadowBlur = 6;
          ctx.fillText(settings.watermarkText, 32, canvas.height - 32);
        }

        dataUrl = canvas.toDataURL('image/jpeg', 0.92);
      } else {
        dataUrl = createSyntheticPhoto();
      }
    } else {
      dataUrl = createSyntheticPhoto();
    }

    const newMedia: CapturedMedia = {
      id: `photo_${Date.now()}`,
      type: 'photo',
      url: dataUrl,
      thumbnailUrl: dataUrl,
      timestamp: Date.now(),
      metadata: {
        width: 4000,
        height: 3000,
        mode,
        zoom,
        flash,
        filter,
        iso: mode === 'night' ? 800 : 50 + Math.floor(Math.random() * 80),
        shutterSpeed: mode === 'night' ? '1/4s' : '1/180s',
        focalLength: zoom < 1 ? '13mm' : zoom > 1 ? '70mm' : '24mm',
        lensFacing: facingMode,
        aspectRatio,
      },
    };

    setMediaList((prev) => [newMedia, ...prev]);
  };

  // Synthetic photo generator fallback if video element isn't capturing frames
  const createSyntheticPhoto = () => {
    const canvas = document.createElement('canvas');
    canvas.width = 1200;
    canvas.height = 900;
    const ctx = canvas.getContext('2d');
    if (ctx) {
      const grad = ctx.createLinearGradient(0, 0, 1200, 900);
      grad.addColorStop(0, '#111827');
      grad.addColorStop(0.5, '#1e293b');
      grad.addColorStop(1, '#0f172a');
      ctx.fillStyle = grad;
      ctx.fillRect(0, 0, 1200, 900);

      // Subject
      ctx.fillStyle = '#FFDE00';
      ctx.beginPath();
      ctx.arc(600, 450, 140, 0, Math.PI * 2);
      ctx.fill();

      // Badge
      ctx.font = 'bold 36px Plus Jakarta Sans, sans-serif';
      ctx.fillStyle = '#ffffff';
      ctx.fillText(`One UI CameraX · ${mode.toUpperCase()} (${zoom}x)`, 60, 100);
      return canvas.toDataURL('image/jpeg', 0.9);
    }
    return '';
  };

  // Start Video Recording
  const startVideoRecording = () => {
    cameraAudio.triggerHaptic('medium');
    cameraAudio.playVideoStartSound();
    setIsRecording(true);
    setIsPaused(false);
    setRecordingSeconds(0);

    recordIntervalRef.current = window.setInterval(() => {
      setRecordingSeconds((prev) => prev + 1);
    }, 1000);

    // Initialize real MediaRecorder if stream exists
    const video = videoElRef.current;
    if (video && video.srcObject) {
      try {
        const stream = video.srcObject as MediaStream;
        recordedChunksRef.current = [];
        const recorder = new MediaRecorder(stream, { mimeType: 'video/webm' });
        recorder.ondataavailable = (e) => {
          if (e.data.size > 0) recordedChunksRef.current.push(e.data);
        };
        recorder.onstop = () => {
          const blob = new Blob(recordedChunksRef.current, { type: 'video/webm' });
          const url = URL.createObjectURL(blob);
          const newMedia: CapturedMedia = {
            id: `video_${Date.now()}`,
            type: 'video',
            url,
            thumbnailUrl: url,
            timestamp: Date.now(),
            duration: recordingSeconds,
            metadata: {
              width: 1920,
              height: 1080,
              mode: 'video',
              zoom,
              flash,
              filter,
              iso: 160,
              shutterSpeed: '1/60s',
              focalLength: '24mm',
              lensFacing: facingMode,
              aspectRatio,
            },
          };
          setMediaList((prev) => [newMedia, ...prev]);
        };
        recorder.start();
        mediaRecorderRef.current = recorder;
      } catch (err) {
        console.warn('MediaRecorder init fallback:', err);
      }
    }
  };

  // Stop Video Recording
  const stopVideoRecording = () => {
    cameraAudio.triggerHaptic('medium');
    cameraAudio.playVideoStopSound();
    setIsRecording(false);
    setIsPaused(false);

    if (recordIntervalRef.current) {
      window.clearInterval(recordIntervalRef.current);
      recordIntervalRef.current = null;
    }

    if (mediaRecorderRef.current && mediaRecorderRef.current.state !== 'inactive') {
      mediaRecorderRef.current.stop();
    } else {
      // Fallback synthetic video item
      const syntheticUrl = 'https://assets.mixkit.co/videos/preview/mixkit-tree-branches-in-the-breeze-1188-large.mp4';
      const newMedia: CapturedMedia = {
        id: `video_${Date.now()}`,
        type: 'video',
        url: syntheticUrl,
        thumbnailUrl: 'https://images.unsplash.com/photo-1506744038136-46273834b3fb?auto=format&fit=crop&w=200&q=80',
        timestamp: Date.now(),
        duration: recordingSeconds || 5,
        metadata: {
          width: 1920,
          height: 1080,
          mode: 'video',
          zoom,
          flash,
          filter,
          iso: 100,
          shutterSpeed: '1/60s',
          focalLength: '24mm',
          lensFacing: facingMode,
          aspectRatio,
        },
      };
      setMediaList((prev) => [newMedia, ...prev]);
    }
  };

  // Pause or Resume Video Recording
  const handlePauseResume = () => {
    if (!isRecording) return;
    if (isPaused) {
      setIsPaused(false);
      if (mediaRecorderRef.current && mediaRecorderRef.current.state === 'paused') {
        mediaRecorderRef.current.resume();
      }
      recordIntervalRef.current = window.setInterval(() => {
        setRecordingSeconds((prev) => prev + 1);
      }, 1000);
    } else {
      setIsPaused(true);
      if (mediaRecorderRef.current && mediaRecorderRef.current.state === 'recording') {
        mediaRecorderRef.current.pause();
      }
      if (recordIntervalRef.current) {
        window.clearInterval(recordIntervalRef.current);
        recordIntervalRef.current = null;
      }
    }
  };

  // Flip Camera Facing
  const handleFlipCamera = () => {
    setFacingMode((prev) => (prev === 'back' ? 'front' : 'back'));
  };

  // Delete Media
  const handleDeleteMedia = (id: string) => {
    setMediaList((prev) => prev.filter((item) => item.id !== id));
  };

  const latestMedia = mediaList[0] || null;

  return (
    <main className="h-full w-full bg-black text-white flex flex-col items-center justify-between overflow-hidden select-none relative font-['Plus_Jakarta_Sans',sans-serif]">
      {/* 1. TOP QUICK SETTINGS BAR */}
      <TopBar
        flash={flash}
        onFlashChange={setFlash}
        timer={timerDuration}
        onTimerChange={setTimerDuration}
        aspectRatio={aspectRatio}
        onAspectRatioChange={setAspectRatio}
        motionPhoto={motionPhoto}
        onToggleMotionPhoto={() => setMotionPhoto(!motionPhoto)}
        filter={filter}
        onFilterChange={setFilter}
        onOpenSettings={() => setIsSettingsOpen(true)}
        onOpenInspector={() => setIsInspectorOpen(true)}
      />

      {/* 2. FLOATING MAIN VIEWFINDER VIEWPORT WITH 24DP ROUNDED CORNERS */}
      <CameraViewfinder
        mode={mode}
        zoom={zoom}
        onZoomChange={setZoom}
        aspectRatio={aspectRatio}
        filter={filter}
        portraitEffect={portraitEffect}
        portraitBlur={portraitBlur}
        onPortraitBlurChange={setPortraitBlur}
        isRecording={isRecording}
        recordingDuration={recordingSeconds}
        gridLines={settings.gridLines}
        sceneOptimizer={settings.sceneOptimizer}
        facingMode={facingMode}
        isShutterFlashing={isShutterFlashing}
        onViewfinderReady={(el) => {
          videoElRef.current = el;
        }}
      />

      {/* Countdown Timer Overlay if active */}
      {countdownRemaining !== null && (
        <div className="absolute inset-0 z-40 flex items-center justify-center pointer-events-none">
          <div className="text-8xl sm:text-9xl font-black text-white drop-shadow-[0_0_24px_rgba(255,222,0,0.8)] animate-ping">
            {countdownRemaining}
          </div>
        </div>
      )}

      {/* 3. HORIZONTAL SLIDER TEXT ROW FOR CAMERA MODES */}
      <ModeSelector
        currentMode={mode}
        onSelectMode={(newMode) => {
          if (isRecording) stopVideoRecording();
          setMode(newMode);
        }}
        disabled={isRecording}
      />

      {/* 4. SPECIALIZED CUSTOM WHITE SHUTTER BUTTON & FLANKING CONTROLS */}
      <ShutterControls
        mode={mode}
        isRecording={isRecording}
        isPaused={isPaused}
        latestMedia={latestMedia}
        onShutterPress={handleShutterTrigger}
        onFlipCamera={handleFlipCamera}
        onOpenGallery={() => setIsGalleryOpen(true)}
        onPauseResumeRecording={handlePauseResume}
        onSnapshotWhileRecording={executePhotoCapture}
      />

      {/* GALLERY VIEWER MODAL */}
      <GalleryModal
        isOpen={isGalleryOpen}
        onClose={() => setIsGalleryOpen(false)}
        mediaList={mediaList}
        onDeleteMedia={handleDeleteMedia}
      />

      {/* SETTINGS MODAL */}
      <SettingsModal
        isOpen={isSettingsOpen}
        onClose={() => setIsSettingsOpen(false)}
        settings={settings}
        onUpdateSettings={(newSettings) =>
          setSettings((prev) => ({ ...prev, ...newSettings }))
        }
      />

      {/* NATIVE ANDROID CAMERAX CODE & ARCHITECTURE INSPECTOR */}
      <CameraXInspector
        isOpen={isInspectorOpen}
        onClose={() => setIsInspectorOpen(false)}
        telemetry={telemetry}
      />
    </main>
  );
}
