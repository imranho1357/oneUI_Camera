import React, { useState } from 'react';
import { ArrowLeft, Copy, Check, Code2, Cpu, Layers, ExternalLink } from 'lucide-react';
import { CameraXTelemetry } from '../types/camera';
import { cameraAudio } from '../utils/audioEffects';

interface CameraXInspectorProps {
  isOpen: boolean;
  onClose: () => void;
  telemetry: CameraXTelemetry;
}

export const CameraXInspector: React.FC<CameraXInspectorProps> = ({
  isOpen,
  onClose,
  telemetry,
}) => {
  const [activeTab, setActiveTab] = useState<'architecture' | 'compose' | 'viewmodel' | 'gradle'>('architecture');
  const [copiedKey, setCopiedKey] = useState<string | null>(null);

  if (!isOpen) return null;

  const copyToClipboard = (text: string, key: string) => {
    navigator.clipboard.writeText(text);
    cameraAudio.triggerHaptic('light');
    setCopiedKey(key);
    setTimeout(() => setCopiedKey(null), 2000);
  };

  const composeCode = `// Samsung One UI Camera Screen in Jetpack Compose + CameraX
package com.samsung.oneui.camera

import androidx.camera.core.*
import androidx.camera.view.PreviewView
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView

@Composable
fun OneUiCameraScreen(viewModel: CameraViewModel) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    val currentMode by viewModel.cameraMode.collectAsState()
    val currentZoom by viewModel.zoomRatio.collectAsState()

    // 1. Dark Background
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF000000))
    ) {
        Column(
            modifier = Modifier.fillMaxSize(),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Top Bar Quick Actions
            TopCameraBar(viewModel)

            // 2. Floating Main Viewfinder with 24dp rounded corners
            Box(
                modifier = Modifier
                    .weight(1f)
                    .padding(horizontal = 16.dp, vertical = 8.dp)
                    .fillMaxWidth()
                    .aspectRatio(3f / 4f)
                    .clip(RoundedCornerShape(24.dp)) // 24dp rounded corners
                    .border(1.dp, Color(0x33FFFFFF), RoundedCornerShape(24.dp))
                    .background(Color(0xFF0A0A0A))
            ) {
                AndroidView(
                    factory = { ctx ->
                        PreviewView(ctx).apply {
                            implementationMode = PreviewView.ImplementationMode.PERFORMANCE
                            scaleType = PreviewView.ScaleType.FILL_CENTER
                            viewModel.bindCameraUseCases(this, lifecycleOwner)
                        }
                    },
                    modifier = Modifier.fillMaxSize()
                )

                // Lens Zoom Toggles (0.6x, 1x, 2x)
                OneUiZoomDock(
                    currentZoom = currentZoom,
                    onZoomSelected = { zoom -> viewModel.setZoom(zoom) },
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .padding(bottom = 16.dp)
                )
            }

            // 3. Horizontal Slider Text Row for Camera Modes
            ModeSliderRow(
                currentMode = currentMode,
                onModeSelected = { mode -> viewModel.setMode(mode) }
            )

            // 4. Specialized Custom White Shutter Button
            ShutterControlsBottomBar(
                isRecording = viewModel.isRecording.collectAsState().value,
                onShutterClick = { viewModel.onShutterClicked() },
                onFlipCamera = { viewModel.toggleCameraFacing() }
            )
        }
    }
}

// Custom White Shutter Button: Solid circle core nested inside white outer ring
@Composable
fun OneUiShutterButton(
    isRecording: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    var isPressed by remember { mutableStateOf(false) }
    val coreScale by animateFloatAsState(if (isPressed) 0.88f else 1.0f)

    Box(
        modifier = modifier
            .size(80.dp)
            .border(
                width = 3.5.dp,
                color = if (isRecording) Color(0xFFEF4444) else Color.White,
                shape = CircleShape
            )
            .padding(5.dp)
            .pointerInput(Unit) {
                detectTapGestures(
                    onPress = {
                        isPressed = true
                        tryAwaitRelease()
                        isPressed = false
                        onClick()
                    }
                )
            },
        contentAlignment = Alignment.Center
    ) {
        // Solid circle core nested inside
        Box(
            modifier = Modifier
                .size(if (isRecording) 28.dp else 58.dp)
                .scale(coreScale)
                .clip(if (isRecording) RoundedCornerShape(8.dp) else CircleShape)
                .background(if (isRecording) Color(0xFFEF4444) else Color.White)
        )
    }
}
`;

  const viewModelCode = `// Android CameraX ViewModel (Jetpack CameraX 1.4+)
package com.samsung.oneui.camera

import android.content.Context
import androidx.camera.core.*
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.video.*
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.ViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

class CameraViewModel : ViewModel() {
    private var cameraProvider: ProcessCameraProvider? = null
    private var camera: Camera? = null
    private var imageCapture: ImageCapture? = null
    private var videoCapture: VideoCapture<Recorder>? = null

    private val _zoomRatio = MutableStateFlow(1f)
    val zoomRatio: StateFlow<Float> = _zoomRatio

    private val _cameraMode = MutableStateFlow("PHOTO")
    val cameraMode: StateFlow<String> = _cameraMode

    private var lensFacing = CameraSelector.LENS_FACING_BACK

    fun bindCameraUseCases(previewView: PreviewView, lifecycleOwner: LifecycleOwner) {
        val cameraProviderFuture = ProcessCameraProvider.getInstance(previewView.context)
        cameraProviderFuture.addListener({
            cameraProvider = cameraProviderFuture.get()

            // 1. Preview Use Case with Target Aspect Ratio 4:3
            val preview = Preview.Builder()
                .setTargetAspectRatio(AspectRatio.RATIO_4_3)
                .build()
                .also { it.setSurfaceProvider(previewView.surfaceProvider) }

            // 2. ImageCapture with Minimal Latency or Zero-Shutter Lag
            imageCapture = ImageCapture.Builder()
                .setCaptureMode(ImageCapture.CAPTURE_MODE_MINIMIZE_LATENCY)
                .setTargetAspectRatio(AspectRatio.RATIO_4_3)
                .build()

            // 3. VideoCapture with Recorder
            val recorder = Recorder.Builder()
                .setQualitySelector(QualitySelector.from(Quality.FHD))
                .build()
            videoCapture = VideoCapture.withOutput(recorder)

            val cameraSelector = CameraSelector.Builder()
                .requireLensFacing(lensFacing)
                .build()

            cameraProvider?.unbindAll()
            camera = cameraProvider?.bindToLifecycle(
                lifecycleOwner,
                cameraSelector,
                preview,
                imageCapture,
                videoCapture
            )
        }, ContextCompat.getMainExecutor(previewView.context))
    }

    fun setZoom(ratio: Float) {
        _zoomRatio.value = ratio
        camera?.cameraControl?.setZoomRatio(ratio)
    }

    fun toggleCameraFacing() {
        lensFacing = if (lensFacing == CameraSelector.LENS_FACING_BACK) {
            CameraSelector.LENS_FACING_FRONT
        } else {
            CameraSelector.LENS_FACING_BACK
        }
    }
}
`;

  const gradleCode = `// Gradle dependencies (build.gradle.kts)
plugins {
    alias(libs.plugins.android.application)
    alias(libs.plugins.kotlin.android)
    alias(libs.plugins.compose.compiler)
}

dependencies {
    // CameraX core library using the camera2 implementation
    val cameraxVersion = "1.4.0-beta02"
    implementation("androidx.camera:camera-core:\${cameraxVersion}")
    implementation("androidx.camera:camera-camera2:\${cameraxVersion}")
    implementation("androidx.camera:camera-lifecycle:\${cameraxVersion}")
    implementation("androidx.camera:camera-video:\${cameraxVersion}")
    implementation("androidx.camera:camera-view:\${cameraxVersion}")
    implementation("androidx.camera:camera-extensions:\${cameraxVersion}")

    // Jetpack Compose & Material 3
    implementation(platform("androidx.compose:compose-bom:2024.09.00"))
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.ui:ui-tooling-preview")
    implementation("androidx.activity:activity-compose:1.9.2")
}
`;

  return (
    <div className="fixed inset-0 z-50 bg-zinc-950 text-white flex flex-col animate-in fade-in duration-200 select-none">
      {/* Header */}
      <div className="flex items-center justify-between px-6 py-4 border-b border-zinc-800 bg-zinc-900/60 backdrop-blur-md">
        <div className="flex items-center gap-3">
          <button
            onClick={() => {
              cameraAudio.triggerHaptic('light');
              onClose();
            }}
            className="w-9 h-9 rounded-full flex items-center justify-center hover:bg-white/10 active:scale-95"
          >
            <ArrowLeft className="w-5 h-5 text-white" />
          </button>
          <div>
            <h1 className="text-base font-bold flex items-center gap-2">
              <span>Android CameraX Architecture</span>
              <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-400 font-mono">
                API 1.4+
              </span>
            </h1>
            <p className="text-xs text-zinc-400">
              Live use-case telemetry and native Jetpack Compose implementation
            </p>
          </div>
        </div>

        {/* Tab switch */}
        <div className="flex items-center gap-1 bg-black/60 p-1 rounded-xl border border-white/10">
          {(
            [
              { id: 'architecture', label: 'Telemetry & Pipeline' },
              { id: 'compose', label: 'OneUiCamera.kt' },
              { id: 'viewmodel', label: 'CameraViewModel.kt' },
              { id: 'gradle', label: 'build.gradle.kts' },
            ] as const
          ).map((t) => (
            <button
              key={t.id}
              onClick={() => {
                cameraAudio.playZoomTick();
                setActiveTab(t.id);
              }}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                activeTab === t.id
                  ? 'bg-emerald-500 text-black font-bold shadow-sm'
                  : 'text-zinc-400 hover:text-white'
              }`}
            >
              {t.label}
            </button>
          ))}
        </div>
      </div>

      {/* Content Area */}
      <div className="flex-1 overflow-y-auto p-6">
        {activeTab === 'architecture' && (
          <div className="max-w-4xl mx-auto space-y-6">
            {/* Live CameraX Pipeline Status */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              <div className="bg-zinc-900/80 rounded-2xl p-4 border border-zinc-800">
                <span className="text-[10px] uppercase tracking-wider text-emerald-400 font-bold block mb-1">
                  Preview UseCase
                </span>
                <div className="text-lg font-bold text-white mb-1">
                  {telemetry.previewState}
                </div>
                <div className="text-xs text-zinc-400">
                  SurfaceProvider: Active ({telemetry.targetAspectRatio})
                </div>
              </div>

              <div className="bg-zinc-900/80 rounded-2xl p-4 border border-zinc-800">
                <span className="text-[10px] uppercase tracking-wider text-emerald-400 font-bold block mb-1">
                  ImageCapture
                </span>
                <div className="text-lg font-bold text-white mb-1">
                  {telemetry.resolution}
                </div>
                <div className="text-xs text-zinc-400">
                  Mode: MINIMIZE_LATENCY / ZSL
                </div>
              </div>

              <div className="bg-zinc-900/80 rounded-2xl p-4 border border-zinc-800">
                <span className="text-[10px] uppercase tracking-wider text-emerald-400 font-bold block mb-1">
                  Lens & Zoom
                </span>
                <div className="text-lg font-bold text-white mb-1">
                  {telemetry.zoomRatio}x
                </div>
                <div className="text-xs text-zinc-400 font-mono">
                  {telemetry.lensFacing}
                </div>
              </div>

              <div className="bg-zinc-900/80 rounded-2xl p-4 border border-zinc-800">
                <span className="text-[10px] uppercase tracking-wider text-emerald-400 font-bold block mb-1">
                  Flash & Torch
                </span>
                <div className="text-lg font-bold text-white mb-1">
                  {telemetry.torchState}
                </div>
                <div className="text-xs text-zinc-400">
                  Flash: {telemetry.flashMode}
                </div>
              </div>
            </div>

            {/* Architecture Pipeline Explanation */}
            <div className="bg-zinc-900/50 rounded-2xl p-6 border border-zinc-800">
              <h3 className="text-sm font-bold text-white mb-3 flex items-center gap-2">
                <Layers className="w-4 h-4 text-emerald-400" />
                <span>How CameraX Binds to the Samsung One UI Viewfinder</span>
              </h3>
              <p className="text-xs text-zinc-300 leading-relaxed mb-4">
                In modern Android architecture, CameraX decouples hardware-level Camera2 complexity into lifecycle-aware Use-Cases.
                The One UI floating viewport with <strong>24dp rounded corners</strong> maps directly to a Jetpack Compose <code>Box</code> with <code>RoundedCornerShape(24.dp)</code> wrapping an <code>AndroidView(PreviewView)</code>.
              </p>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs">
                <div className="p-3 bg-black/40 rounded-xl border border-white/5">
                  <div className="font-bold text-zinc-200 mb-1">1. Viewfinder Surface</div>
                  <p className="text-zinc-400 leading-normal">
                    <code>Preview.Builder().setTargetAspectRatio()</code> supplies raw YUV/SurfaceTexture frames directly into the floating 24dp viewport without aspect stretching.
                  </p>
                </div>
                <div className="p-3 bg-black/40 rounded-xl border border-white/5">
                  <div className="font-bold text-zinc-200 mb-1">2. Lens Zoom Controls</div>
                  <p className="text-zinc-400 leading-normal">
                    The <code>0.6x</code>, <code>1x</code>, and <code>2x</code> toggles map directly to <code>cameraControl.setZoomRatio(float)</code>, dynamically selecting the physical multi-camera lens array on Galaxy devices.
                  </p>
                </div>
                <div className="p-3 bg-black/40 rounded-xl border border-white/5">
                  <div className="font-bold text-zinc-200 mb-1">3. Custom Shutter Button</div>
                  <p className="text-zinc-400 leading-normal">
                    The nested solid white core triggers <code>imageCapture.takePicture()</code>, while long-press seamlessly streams to <code>videoCapture.output.start()</code>.
                  </p>
                </div>
              </div>
            </div>
          </div>
        )}

        {activeTab === 'compose' && (
          <div className="max-w-4xl mx-auto">
            <div className="flex items-center justify-between mb-3">
              <span className="text-xs font-mono text-zinc-400">OneUiCameraScreen.kt</span>
              <button
                onClick={() => copyToClipboard(composeCode, 'compose')}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-emerald-500/20 text-emerald-400 text-xs font-semibold hover:bg-emerald-500/30"
              >
                {copiedKey === 'compose' ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copiedKey === 'compose' ? 'Copied!' : 'Copy Kotlin Code'}</span>
              </button>
            </div>
            <pre className="p-4 bg-zinc-900/90 rounded-2xl border border-zinc-800 text-xs font-mono text-zinc-300 overflow-x-auto leading-relaxed max-h-[60vh]">
              {composeCode}
            </pre>
          </div>
        )}

        {activeTab === 'viewmodel' && (
          <div className="max-w-4xl mx-auto">
            <div className="flex items-center justify-between mb-3">
              <span className="text-xs font-mono text-zinc-400">CameraViewModel.kt</span>
              <button
                onClick={() => copyToClipboard(viewModelCode, 'viewmodel')}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-emerald-500/20 text-emerald-400 text-xs font-semibold hover:bg-emerald-500/30"
              >
                {copiedKey === 'viewmodel' ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copiedKey === 'viewmodel' ? 'Copied!' : 'Copy ViewModel'}</span>
              </button>
            </div>
            <pre className="p-4 bg-zinc-900/90 rounded-2xl border border-zinc-800 text-xs font-mono text-zinc-300 overflow-x-auto leading-relaxed max-h-[60vh]">
              {viewModelCode}
            </pre>
          </div>
        )}

        {activeTab === 'gradle' && (
          <div className="max-w-4xl mx-auto">
            <div className="flex items-center justify-between mb-3">
              <span className="text-xs font-mono text-zinc-400">build.gradle.kts</span>
              <button
                onClick={() => copyToClipboard(gradleCode, 'gradle')}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-emerald-500/20 text-emerald-400 text-xs font-semibold hover:bg-emerald-500/30"
              >
                {copiedKey === 'gradle' ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copiedKey === 'gradle' ? 'Copied!' : 'Copy Gradle Config'}</span>
              </button>
            </div>
            <pre className="p-4 bg-zinc-900/90 rounded-2xl border border-zinc-800 text-xs font-mono text-zinc-300 overflow-x-auto leading-relaxed max-h-[60vh]">
              {gradleCode}
            </pre>
          </div>
        )}
      </div>
    </div>
  );
};
