import React, { useState, useRef } from 'react';
import { RefreshCw, Pause, Play, Camera as CameraIcon } from 'lucide-react';
import { CameraMode, CapturedMedia } from '../types/camera';
import { cameraAudio } from '../utils/audioEffects';

interface ShutterControlsProps {
  mode: CameraMode;
  isRecording: boolean;
  isPaused: boolean;
  latestMedia: CapturedMedia | null;
  onShutterPress: () => void;
  onFlipCamera: () => void;
  onOpenGallery: () => void;
  onPauseResumeRecording: () => void;
  onSnapshotWhileRecording: () => void;
}

export const ShutterControls: React.FC<ShutterControlsProps> = ({
  mode,
  isRecording,
  isPaused,
  latestMedia,
  onShutterPress,
  onFlipCamera,
  onOpenGallery,
  onPauseResumeRecording,
  onSnapshotWhileRecording,
}) => {
  const [isPressing, setIsPressing] = useState<boolean>(false);
  const [isFlippingAnim, setIsFlippingAnim] = useState<boolean>(false);
  const pressTimerRef = useRef<number | null>(null);

  const handlePointerDown = () => {
    setIsPressing(true);
    cameraAudio.triggerHaptic('medium');
  };

  const handlePointerUp = () => {
    setIsPressing(false);
    if (pressTimerRef.current) {
      window.clearTimeout(pressTimerRef.current);
      pressTimerRef.current = null;
    }
  };

  const handleClickShutter = () => {
    onShutterPress();
  };

  const handleFlipClick = () => {
    setIsFlippingAnim(true);
    cameraAudio.triggerHaptic('light');
    cameraAudio.playZoomTick();
    onFlipCamera();
    setTimeout(() => setIsFlippingAnim(false), 450);
  };

  return (
    <div className="w-full max-w-md px-6 py-4 flex items-center justify-between select-none">
      {/* LEFT CONTROL: GALLERY THUMBNAIL (or PAUSE/RESUME during recording) */}
      <div className="w-14 h-14 flex items-center justify-center">
        {isRecording ? (
          <button
            onClick={() => {
              cameraAudio.triggerHaptic('light');
              onPauseResumeRecording();
            }}
            className="w-12 h-12 rounded-full bg-white/15 backdrop-blur-md border border-white/20 flex items-center justify-center text-white active:scale-90 transition-transform"
            title={isPaused ? 'Resume Recording' : 'Pause Recording'}
          >
            {isPaused ? <Play className="w-5 h-5 fill-white" /> : <Pause className="w-5 h-5 fill-white" />}
          </button>
        ) : (
          <button
            onClick={() => {
              cameraAudio.triggerHaptic('light');
              onOpenGallery();
            }}
            className="group relative w-12 h-12 rounded-full overflow-hidden border-2 border-white/40 bg-zinc-800 shadow-lg active:scale-95 transition-transform flex items-center justify-center"
            title="Open Gallery"
          >
            {latestMedia ? (
              <img
                src={latestMedia.thumbnailUrl || latestMedia.url}
                alt="Latest captured shot"
                className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-200"
              />
            ) : (
              <div className="w-full h-full bg-gradient-to-br from-zinc-700 to-zinc-900 flex items-center justify-center">
                <div className="w-4 h-4 rounded-full border border-white/30" />
              </div>
            )}
            {latestMedia && (
              <div className="absolute inset-0 bg-black/10 group-hover:bg-transparent transition-colors" />
            )}
          </button>
        )}
      </div>

      {/* CENTER: SPECIALIZED CUSTOM WHITE SHUTTER BUTTON */}
      {/* "built with a solid circle core nested inside a white outer ring" */}
      <div className="flex items-center justify-center relative">
        <button
          onPointerDown={handlePointerDown}
          onPointerUp={handlePointerUp}
          onPointerLeave={handlePointerUp}
          onClick={handleClickShutter}
          className="relative focus:outline-none cursor-pointer group active:scale-95 transition-transform duration-100"
          title={mode === 'video' ? (isRecording ? 'Stop Recording' : 'Start Recording') : 'Take Photo'}
        >
          {/* Outer Ring */}
          <div
            className={`w-[78px] h-[78px] rounded-full border-[3.5px] border-white flex items-center justify-center p-1 transition-all duration-200 ${
              isRecording
                ? 'border-red-500 shadow-[0_0_16px_rgba(239,68,68,0.5)]'
                : 'shadow-[0_4px_16px_rgba(0,0,0,0.5)]'
            } ${isPressing ? 'scale-95' : 'scale-100'}`}
          >
            {/* Nested Solid Circle Core */}
            {mode === 'video' ? (
              // Video Mode Inner Core
              <div
                className={`transition-all duration-200 ${
                  isRecording
                    ? 'w-7 h-7 rounded-md bg-red-500 animate-pulse'
                    : 'w-14 h-14 rounded-full bg-red-500 shadow-md'
                } ${isPressing ? 'scale-90 opacity-90' : 'scale-100'}`}
              />
            ) : (
              // Photo / Portrait Mode Inner Core (Solid White Circle Core)
              <div
                className={`w-[58px] h-[58px] rounded-full bg-white shadow-md transition-all duration-150 ${
                  isPressing ? 'scale-90 opacity-90' : 'scale-100'
                }`}
              />
            )}
          </div>
        </button>
      </div>

      {/* RIGHT CONTROL: FLIP CAMERA (or SNAPSHOT PHOTO during recording) */}
      <div className="w-14 h-14 flex items-center justify-center">
        {isRecording ? (
          <button
            onClick={() => {
              cameraAudio.triggerHaptic('medium');
              cameraAudio.playShutterSound();
              onSnapshotWhileRecording();
            }}
            className="w-11 h-11 rounded-full bg-white/20 backdrop-blur-md border border-white/40 flex items-center justify-center text-white active:scale-90 transition-transform shadow-md"
            title="Take snapshot while recording"
          >
            <div className="w-6 h-6 rounded-full bg-white" />
          </button>
        ) : (
          <button
            onClick={handleFlipClick}
            className="w-12 h-12 rounded-full bg-zinc-800/80 backdrop-blur-md border border-white/15 flex items-center justify-center text-white active:scale-90 transition-all duration-200 shadow-lg"
            title="Switch Camera (Front/Rear)"
          >
            <RefreshCw
              className={`w-5 h-5 text-white transition-transform duration-500 ${
                isFlippingAnim ? 'rotate-180' : ''
              }`}
            />
          </button>
        )}
      </div>
    </div>
  );
};
