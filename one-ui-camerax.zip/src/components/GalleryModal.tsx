import React, { useState } from 'react';
import {
  ArrowLeft,
  Trash2,
  Share2,
  Download,
  Info,
  ChevronLeft,
  ChevronRight,
  Play,
} from 'lucide-react';
import { CapturedMedia } from '../types/camera';
import { cameraAudio } from '../utils/audioEffects';

interface GalleryModalProps {
  isOpen: boolean;
  onClose: () => void;
  mediaList: CapturedMedia[];
  onDeleteMedia: (id: string) => void;
}

export const GalleryModal: React.FC<GalleryModalProps> = ({
  isOpen,
  onClose,
  mediaList,
  onDeleteMedia,
}) => {
  const [selectedIndex, setSelectedIndex] = useState<number>(0);
  const [showDetails, setShowDetails] = useState<boolean>(false);

  if (!isOpen) return null;

  const currentItem = mediaList[selectedIndex] || null;

  const handleNext = () => {
    if (selectedIndex < mediaList.length - 1) {
      cameraAudio.playZoomTick();
      setSelectedIndex(selectedIndex + 1);
    }
  };

  const handlePrev = () => {
    if (selectedIndex > 0) {
      cameraAudio.playZoomTick();
      setSelectedIndex(selectedIndex - 1);
    }
  };

  const handleDelete = () => {
    if (!currentItem) return;
    cameraAudio.triggerHaptic('medium');
    onDeleteMedia(currentItem.id);
    if (selectedIndex >= mediaList.length - 1 && selectedIndex > 0) {
      setSelectedIndex(selectedIndex - 1);
    }
  };

  const handleDownload = () => {
    if (!currentItem) return;
    cameraAudio.triggerHaptic('light');
    const a = document.createElement('a');
    a.href = currentItem.url;
    a.download = `OneUI_CameraX_${currentItem.id}.${currentItem.type === 'video' ? 'webm' : 'jpg'}`;
    a.click();
  };

  const formatDate = (timestamp: number) => {
    const d = new Date(timestamp);
    return d.toLocaleString('en-US', {
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit',
    });
  };

  return (
    <div className="fixed inset-0 z-50 bg-black flex flex-col justify-between animate-in fade-in duration-200 select-none">
      {/* Top Bar */}
      <div className="flex items-center justify-between px-4 py-3 bg-gradient-to-b from-black/80 to-transparent z-10">
        <button
          onClick={() => {
            cameraAudio.triggerHaptic('light');
            onClose();
          }}
          className="w-10 h-10 rounded-full flex items-center justify-center hover:bg-white/10 active:scale-95 text-white"
        >
          <ArrowLeft className="w-6 h-6" />
        </button>

        <div className="text-center">
          <h2 className="text-sm font-semibold text-white">
            {currentItem ? formatDate(currentItem.timestamp) : 'Gallery'}
          </h2>
          {mediaList.length > 0 && (
            <p className="text-[11px] text-zinc-400">
              {selectedIndex + 1} of {mediaList.length}
            </p>
          )}
        </div>

        <button
          onClick={() => setShowDetails(!showDetails)}
          className={`w-10 h-10 rounded-full flex items-center justify-center hover:bg-white/10 active:scale-95 ${
            showDetails ? 'text-[#FFDE00]' : 'text-white'
          }`}
          title="Details / EXIF"
        >
          <Info className="w-5 h-5" />
        </button>
      </div>

      {/* Main Preview Area */}
      <div className="relative flex-1 flex items-center justify-center overflow-hidden px-2">
        {mediaList.length === 0 ? (
          <div className="text-center text-zinc-500">
            <p className="text-base font-semibold mb-1">No pictures or videos</p>
            <p className="text-xs">Take some shots with the Samsung One UI camera.</p>
          </div>
        ) : currentItem ? (
          <div className="relative max-h-full max-w-full flex items-center justify-center">
            {currentItem.type === 'video' ? (
              <video
                src={currentItem.url}
                controls
                autoPlay
                className="max-h-[75vh] max-w-full rounded-2xl shadow-2xl object-contain"
              />
            ) : (
              <img
                src={currentItem.url}
                alt="Captured Shot"
                className="max-h-[75vh] max-w-full rounded-2xl shadow-2xl object-contain animate-in zoom-in-95 duration-150"
              />
            )}
          </div>
        ) : null}

        {/* Previous Button */}
        {selectedIndex > 0 && (
          <button
            onClick={handlePrev}
            className="absolute left-4 top-1/2 -translate-y-1/2 w-11 h-11 rounded-full bg-black/50 backdrop-blur-md border border-white/10 text-white flex items-center justify-center hover:bg-black/70 active:scale-95"
          >
            <ChevronLeft className="w-6 h-6" />
          </button>
        )}

        {/* Next Button */}
        {selectedIndex < mediaList.length - 1 && (
          <button
            onClick={handleNext}
            className="absolute right-4 top-1/2 -translate-y-1/2 w-11 h-11 rounded-full bg-black/50 backdrop-blur-md border border-white/10 text-white flex items-center justify-center hover:bg-black/70 active:scale-95"
          >
            <ChevronRight className="w-6 h-6" />
          </button>
        )}
      </div>

      {/* EXIF Details Drawer */}
      {showDetails && currentItem && (
        <div className="px-6 py-4 bg-zinc-900/95 backdrop-blur-2xl border-t border-white/15 animate-in slide-in-from-bottom duration-200">
          <h3 className="text-xs font-bold uppercase tracking-wider text-[#FFDE00] mb-2">
            CameraX Image Telemetry & EXIF
          </h3>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
            <div>
              <span className="text-zinc-400 block text-[10px]">DEVICE & API</span>
              <span className="font-semibold text-white">CameraX · One UI</span>
            </div>
            <div>
              <span className="text-zinc-400 block text-[10px]">RESOLUTION</span>
              <span className="font-semibold text-white">
                {currentItem.metadata.width} × {currentItem.metadata.height}
              </span>
            </div>
            <div>
              <span className="text-zinc-400 block text-[10px]">ZOOM & LENS</span>
              <span className="font-semibold text-white">
                {currentItem.metadata.zoom}x · {currentItem.metadata.lensFacing}
              </span>
            </div>
            <div>
              <span className="text-zinc-400 block text-[10px]">EXPOSURE</span>
              <span className="font-semibold text-white font-mono">
                {currentItem.metadata.shutterSpeed} · ISO {currentItem.metadata.iso}
              </span>
            </div>
          </div>
        </div>
      )}

      {/* Bottom Actions Bar */}
      {mediaList.length > 0 && (
        <div className="flex items-center justify-around py-4 bg-gradient-to-t from-black/90 to-transparent border-t border-white/10">
          <button
            onClick={handleDownload}
            className="flex flex-col items-center gap-1 text-zinc-300 hover:text-white active:scale-95 transition-transform"
          >
            <Download className="w-5 h-5" />
            <span className="text-[10px] font-medium">Save</span>
          </button>

          <button
            onClick={() => {
              if (navigator.share && currentItem) {
                navigator.share({
                  title: 'Captured with One UI CameraX',
                  url: currentItem.url,
                }).catch(() => {});
              } else {
                handleDownload();
              }
            }}
            className="flex flex-col items-center gap-1 text-zinc-300 hover:text-white active:scale-95 transition-transform"
          >
            <Share2 className="w-5 h-5" />
            <span className="text-[10px] font-medium">Share</span>
          </button>

          <button
            onClick={handleDelete}
            className="flex flex-col items-center gap-1 text-red-400 hover:text-red-300 active:scale-95 transition-transform"
          >
            <Trash2 className="w-5 h-5" />
            <span className="text-[10px] font-medium">Delete</span>
          </button>
        </div>
      )}
    </div>
  );
};
