import React, { useRef, useEffect, useState, useCallback } from 'react';
import { Sparkles, Sun, Maximize2, Zap, AlertCircle } from 'lucide-react';
import { CameraMode, ZoomLevel, AspectRatio, FilterType, PortraitEffect } from '../types/camera';
import { cameraAudio } from '../utils/audioEffects';

interface CameraViewfinderProps {
  mode: CameraMode;
  zoom: ZoomLevel;
  onZoomChange: (zoom: ZoomLevel) => void;
  aspectRatio: AspectRatio;
  filter: FilterType;
  portraitEffect: PortraitEffect;
  portraitBlur: number;
  onPortraitBlurChange: (val: number) => void;
  isRecording: boolean;
  recordingDuration: number;
  gridLines: boolean;
  sceneOptimizer: boolean;
  facingMode: 'back' | 'front';
  isShutterFlashing: boolean;
  onTapFocus?: (point: { x: number; y: number }) => void;
  onViewfinderReady?: (videoEl: HTMLVideoElement | null) => void;
}

export const CameraViewfinder: React.FC<CameraViewfinderProps> = ({
  mode,
  zoom,
  onZoomChange,
  aspectRatio,
  filter,
  portraitEffect,
  portraitBlur,
  onPortraitBlurChange,
  isRecording,
  recordingDuration,
  gridLines,
  sceneOptimizer,
  facingMode,
  isShutterFlashing,
  onTapFocus,
  onViewfinderReady,
}) => {
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const containerRef = useRef<HTMLDivElement | null>(null);
  const canvasSimRef = useRef<HTMLCanvasElement | null>(null);

  const [hasCameraStream, setHasCameraStream] = useState<boolean>(false);
  const [streamError, setStreamError] = useState<string | null>(null);
  const [isRequestingCamera, setIsRequestingCamera] = useState<boolean>(false);

  // Focus point state
  const [focusPoint, setFocusPoint] = useState<{ x: number; y: number; exposure: number } | null>(null);
  const focusTimeoutRef = useRef<number | null>(null);

  // Expanded zoom dock
  const [isZoomDockOpen, setIsZoomDockOpen] = useState<boolean>(false);

  // Detected scene for One UI Scene Optimizer
  const [detectedScene, setDetectedScene] = useState<string>('Standard');

  // Horizon level (tilt in degrees, simulated / device orientation)
  const [tiltDegree, setTiltDegree] = useState<number>(0);

  // Start real camera stream
  const startCamera = useCallback(async () => {
    setIsRequestingCamera(true);
    setStreamError(null);

    try {
      if (videoRef.current && videoRef.current.srcObject) {
        const oldStream = videoRef.current.srcObject as MediaStream;
        oldStream.getTracks().forEach(track => track.stop());
      }

      // Check if getUserMedia is supported
      if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
        throw new Error('MediaDevices not supported in this environment');
      }

      const constraints: MediaStreamConstraints = {
        video: {
          facingMode: facingMode === 'back' ? { ideal: 'environment' } : { ideal: 'user' },
          width: { ideal: 1920 },
          height: { ideal: 1080 },
        },
        audio: mode === 'video',
      };

      const stream = await navigator.mediaDevices.getUserMedia(constraints);
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        await videoRef.current.play();
        setHasCameraStream(true);
        if (onViewfinderReady) {
          onViewfinderReady(videoRef.current);
        }
      }
    } catch (err: unknown) {
      console.warn('Real camera stream failed or unavailable, fallback to simulated sensor:', err);
      const errMsg = err instanceof Error ? err.message : 'Camera access restricted';
      setStreamError(errMsg);
      setHasCameraStream(false);
    } finally {
      setIsRequestingCamera(false);
    }
  }, [facingMode, mode, onViewfinderReady]);

  useEffect(() => {
    startCamera();
    return () => {
      if (videoRef.current && videoRef.current.srcObject) {
        const stream = videoRef.current.srcObject as MediaStream;
        stream.getTracks().forEach(track => track.stop());
      }
    };
  }, [facingMode, startCamera]);

  // Dynamic simulation canvas if camera stream isn't available
  useEffect(() => {
    if (hasCameraStream) return;
    const canvas = canvasSimRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animId: number;
    let t = 0;

    const render = () => {
      t += 0.015;
      const w = (canvas.width = canvas.clientWidth || 640);
      const h = (canvas.height = canvas.clientHeight || 480);

      // Background atmospheric gradient
      const grad = ctx.createLinearGradient(0, 0, w, h);
      if (mode === 'night') {
        grad.addColorStop(0, '#0a0d1a');
        grad.addColorStop(0.5, '#121b2d');
        grad.addColorStop(1, '#05070c');
      } else if (mode === 'portrait') {
        grad.addColorStop(0, '#1c1f26');
        grad.addColorStop(0.5, '#2b2a36');
        grad.addColorStop(1, '#181a20');
      } else {
        grad.addColorStop(0, '#141c28');
        grad.addColorStop(0.4, '#1e2d44');
        grad.addColorStop(0.8, '#243447');
        grad.addColorStop(1, '#0e1622');
      }
      ctx.fillStyle = grad;
      ctx.fillRect(0, 0, w, h);

      // Subtle simulated horizon / landscape elements
      const sunX = w * 0.7 + Math.sin(t * 0.3) * 15;
      const sunY = h * 0.35 + Math.cos(t * 0.2) * 10;
      const sunGrad = ctx.createRadialGradient(sunX, sunY, 10, sunX, sunY, 180);
      sunGrad.addColorStop(0, 'rgba(255, 230, 160, 0.45)');
      sunGrad.addColorStop(0.5, 'rgba(255, 170, 90, 0.15)');
      sunGrad.addColorStop(1, 'transparent');
      ctx.fillStyle = sunGrad;
      ctx.fillRect(0, 0, w, h);

      // Simulated focal subject (portrait figure or geometric city horizon)
      const cx = w * 0.5 + Math.sin(t * 0.5) * 8;
      const cy = h * 0.55 + Math.cos(t * 0.4) * 6;

      // Subject silhouette / model simulation
      ctx.save();
      if (mode === 'portrait') {
        // Human portrait silhouette
        ctx.fillStyle = 'rgba(235, 210, 195, 0.85)';
        // Head
        ctx.beginPath();
        ctx.arc(cx, cy - 60, 45, 0, Math.PI * 2);
        ctx.fill();
        // Shoulders
        ctx.beginPath();
        ctx.ellipse(cx, cy + 40, 90, 65, 0, 0, Math.PI * 2);
        ctx.fillStyle = 'rgba(70, 95, 130, 0.9)';
        ctx.fill();
        // Hair
        ctx.fillStyle = 'rgba(40, 28, 22, 0.95)';
        ctx.beginPath();
        ctx.arc(cx, cy - 65, 47, Math.PI * 0.8, Math.PI * 2.2);
        ctx.fill();
      } else {
        // Modern architectural elements
        ctx.fillStyle = 'rgba(255, 255, 255, 0.08)';
        for (let i = 0; i < 7; i++) {
          const bh = 120 + Math.sin(i * 1.5) * 60;
          const bx = w * 0.2 + i * (w * 0.09);
          ctx.fillRect(bx, h * 0.7 - bh, w * 0.07, bh);
        }
        // Central focus subject
        ctx.fillStyle = 'rgba(255, 215, 64, 0.7)';
        ctx.beginPath();
        ctx.arc(cx, cy, 32, 0, Math.PI * 2);
        ctx.fill();
      }
      ctx.restore();

      // Sensor grain & live camera telemetry simulation
      ctx.fillStyle = 'rgba(255, 255, 255, 0.025)';
      for (let i = 0; i < 15; i++) {
        const rx = Math.random() * w;
        const ry = Math.random() * h;
        ctx.fillRect(rx, ry, 2, 2);
      }

      animId = requestAnimationFrame(render);
    };

    render();
    return () => cancelAnimationFrame(animId);
  }, [hasCameraStream, mode]);

  // Tap to focus handler
  const handleTapViewfinder = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!containerRef.current) return;
    const rect = containerRef.current.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;

    cameraAudio.playFocusLockSound();
    cameraAudio.triggerHaptic('light');

    setFocusPoint({ x, y, exposure: 0 });

    if (focusTimeoutRef.current) {
      window.clearTimeout(focusTimeoutRef.current);
    }
    // Auto dismiss after 3.5s like Samsung camera
    focusTimeoutRef.current = window.setTimeout(() => {
      setFocusPoint(null);
    }, 3500);

    if (onTapFocus) {
      onTapFocus({ x: x / rect.width, y: y / rect.height });
    }
  };

  // Adjust focus exposure slider
  const handleExposureChange = (delta: number) => {
    if (!focusPoint) return;
    setFocusPoint(prev => {
      if (!prev) return null;
      const nextExp = Math.max(-2, Math.min(2, prev.exposure + delta));
      return { ...prev, exposure: nextExp };
    });
  };

  // Scene detection cycle based on mode
  useEffect(() => {
    if (mode === 'portrait') setDetectedScene('Person');
    else if (mode === 'night') setDetectedScene('Night Scene');
    else if (mode === 'pro') setDetectedScene('Manual');
    else if (zoom >= 10) setDetectedScene('Super Telephoto');
    else setDetectedScene('Natural Scene');
  }, [mode, zoom]);

  // Subtle simulated horizon leveler
  useEffect(() => {
    const interval = setInterval(() => {
      // gentle organic float around 0°
      setTiltDegree((Math.random() - 0.5) * 1.2);
    }, 2000);
    return () => clearInterval(interval);
  }, []);

  // Format recording timer
  const formatTimer = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  // Filter CSS mapping
  const getFilterStyle = (): React.CSSProperties => {
    let filterString = '';
    switch (filter) {
      case 'warm':
        filterString = 'sepia(0.25) saturate(1.2) hue-rotate(-10deg)';
        break;
      case 'cool':
        filterString = 'hue-rotate(15deg) saturate(1.1) brightness(1.03)';
        break;
      case 'vivid':
        filterString = 'saturate(1.55) contrast(1.15)';
        break;
      case 'mono':
        filterString = 'grayscale(1) contrast(1.2)';
        break;
      case 'film':
        filterString = 'contrast(0.95) brightness(1.05) saturate(1.15) sepia(0.15)';
        break;
      case 'vintage':
        filterString = 'sepia(0.5) contrast(1.1) brightness(0.95)';
        break;
      case 'noir':
        filterString = 'grayscale(1) contrast(1.5) brightness(0.85)';
        break;
      default:
        filterString = 'none';
    }

    if (focusPoint && focusPoint.exposure !== 0) {
      const expBright = 1 + focusPoint.exposure * 0.15;
      filterString += ` brightness(${expBright})`;
    }

    return { filter: filterString };
  };

  // Aspect ratio height calculation
  const getAspectRatioClasses = () => {
    switch (aspectRatio) {
      case '1:1':
        return 'aspect-square max-h-[75vh]';
      case '9:16':
        return 'aspect-[9/16] h-[78vh]';
      case 'full':
        return 'h-full w-full';
      case '3:4':
      default:
        return 'aspect-[3/4] h-[68vh] max-h-[720px]';
    }
  };

  return (
    <div className="relative w-full flex-1 flex flex-col items-center justify-center p-2 sm:p-3 overflow-hidden">
      {/* FLOATING MAIN VIEWFINDER VIEWPORT WITH EXACT 24DP (rounded-[24px]) CORNERS */}
      <div
        ref={containerRef}
        onClick={handleTapViewfinder}
        className={`relative w-full max-w-md ${getAspectRatioClasses()} rounded-[24px] overflow-hidden bg-zinc-950 shadow-[0_12px_48px_rgba(0,0,0,0.85)] border border-white/10 select-none cursor-crosshair transition-all duration-300 ease-out`}
        style={{
          boxShadow: '0 8px 32px 0 rgba(0, 0, 0, 0.7), inset 0 0 0 1px rgba(255, 255, 255, 0.08)',
        }}
      >
        {/* Real Video Stream Element */}
        <video
          ref={videoRef}
          autoPlay
          playsInline
          muted
          className={`absolute inset-0 w-full h-full object-cover transition-transform duration-300 ${
            facingMode === 'front' ? 'scale-x-[-1]' : ''
          } ${hasCameraStream ? 'opacity-100' : 'opacity-0 pointer-events-none'}`}
          style={{
            transform: `${facingMode === 'front' ? 'scaleX(-1)' : ''} scale(${zoom >= 1 ? 1 + (zoom - 1) * 0.15 : 1})`,
            ...getFilterStyle(),
          }}
        />

        {/* Fallback Simulation Canvas (if camera stream unavailable or loading) */}
        {!hasCameraStream && (
          <canvas
            ref={canvasSimRef}
            className="absolute inset-0 w-full h-full object-cover transition-transform duration-300"
            style={{
              transform: `scale(${zoom >= 1 ? 1 + (zoom - 1) * 0.15 : 1})`,
              ...getFilterStyle(),
            }}
          />
        )}

        {/* Shutter White Flash animation on capture */}
        <div
          className={`absolute inset-0 bg-white pointer-events-none transition-opacity duration-150 z-30 ${
            isShutterFlashing ? 'opacity-95' : 'opacity-0'
          }`}
        />

        {/* Stream status or permission banner if needed */}
        {!hasCameraStream && (
          <div className="absolute top-4 left-4 right-4 z-20 flex items-center justify-between px-3 py-2 bg-black/60 backdrop-blur-md rounded-xl border border-white/10 text-xs">
            <div className="flex items-center gap-2 text-zinc-300">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
              <span>CameraX Preview Simulator</span>
            </div>
            <button
              onClick={(e) => {
                e.stopPropagation();
                startCamera();
              }}
              disabled={isRequestingCamera}
              className="px-2.5 py-1 text-[11px] font-semibold text-black bg-white rounded-md hover:bg-zinc-200 transition-colors"
            >
              {isRequestingCamera ? 'Connecting...' : 'Use Webcam'}
            </button>
          </div>
        )}

        {/* 3x3 Rule of Thirds Grid Lines */}
        {gridLines && (
          <div className="absolute inset-0 pointer-events-none grid grid-cols-3 grid-rows-3 z-10">
            <div className="border-r border-b border-white/15" />
            <div className="border-r border-b border-white/15" />
            <div className="border-b border-white/15" />
            <div className="border-r border-b border-white/15" />
            <div className="border-r border-b border-white/15" />
            <div className="border-b border-white/15" />
            <div className="border-r border-white/15" />
            <div className="border-r border-white/15" />
            <div />
          </div>
        )}

        {/* Horizon Level Indicator (Samsung yellow level line) */}
        <div className="absolute inset-x-12 top-1/2 -translate-y-1/2 pointer-events-none z-10 flex items-center justify-between">
          <div
            className={`h-[1.5px] w-12 transition-all duration-300 ${
              Math.abs(tiltDegree) < 0.8 ? 'bg-[#FFDE00] shadow-[0_0_8px_#FFDE00]' : 'bg-white/40'
            }`}
            style={{ transform: `rotate(${tiltDegree}deg)` }}
          />
          <div
            className={`w-2.5 h-2.5 rounded-full border transition-all duration-300 ${
              Math.abs(tiltDegree) < 0.8
                ? 'border-[#FFDE00] bg-[#FFDE00]/40'
                : 'border-white/40 bg-transparent'
            }`}
          />
          <div
            className={`h-[1.5px] w-12 transition-all duration-300 ${
              Math.abs(tiltDegree) < 0.8 ? 'bg-[#FFDE00] shadow-[0_0_8px_#FFDE00]' : 'bg-white/40'
            }`}
            style={{ transform: `rotate(${tiltDegree}deg)` }}
          />
        </div>

        {/* Video Mode: Recording overlay & elapsed duration */}
        {isRecording && (
          <div className="absolute top-4 left-1/2 -translate-x-1/2 z-20 flex items-center gap-2.5 px-3.5 py-1.5 bg-black/60 backdrop-blur-md rounded-full border border-red-500/30">
            <span className="w-2.5 h-2.5 rounded-full bg-red-500 animate-ping" />
            <span className="text-xs font-mono font-bold text-white tracking-widest tabular-nums">
              {formatTimer(recordingDuration)}
            </span>
            <div className="flex items-center gap-0.5 ml-1">
              <span className="w-0.5 h-2.5 bg-white/70 rounded-full animate-pulse" />
              <span className="w-0.5 h-4 bg-red-400 rounded-full animate-pulse delay-75" />
              <span className="w-0.5 h-1.5 bg-white/70 rounded-full animate-pulse delay-150" />
            </div>
          </div>
        )}

        {/* Portrait Mode: Live Bokeh depth blur & effect ready badge */}
        {mode === 'portrait' && (
          <>
            <div className="absolute top-4 left-1/2 -translate-x-1/2 z-20 px-3 py-1 bg-black/50 backdrop-blur-md rounded-full border border-[#FFDE00]/40 flex items-center gap-1.5">
              <span className="w-2 h-2 rounded-full bg-[#FFDE00]" />
              <span className="text-[11px] font-semibold text-[#FFDE00] tracking-wide">
                Effect ready
              </span>
            </div>

            {/* Bokeh Blur Slider (1-7) */}
            <div className="absolute right-3 top-1/2 -translate-y-1/2 z-20 flex flex-col items-center gap-2 p-2 bg-black/60 backdrop-blur-md rounded-full border border-white/10">
              <span className="text-[10px] font-bold text-zinc-400">BLUR</span>
              <div className="flex flex-col-reverse items-center gap-1 py-1">
                {[1, 2, 3, 4, 5, 6, 7].map((lvl) => (
                  <button
                    key={lvl}
                    onClick={(e) => {
                      e.stopPropagation();
                      onPortraitBlurChange(lvl);
                      cameraAudio.playZoomTick();
                    }}
                    className={`w-5 h-5 rounded-full text-[10px] font-bold flex items-center justify-center transition-all ${
                      portraitBlur === lvl
                        ? 'bg-[#FFDE00] text-black scale-110 shadow-sm'
                        : 'text-zinc-400 hover:text-white'
                    }`}
                  >
                    {lvl}
                  </button>
                ))}
              </div>
            </div>
          </>
        )}

        {/* Tap to Focus: Samsung yellow circular ring & exposure slider */}
        {focusPoint && (
          <div
            className="absolute pointer-events-none z-30 transition-all duration-150"
            style={{
              left: `${focusPoint.x}px`,
              top: `${focusPoint.y}px`,
              transform: 'translate(-50%, -50%)',
            }}
          >
            {/* Pulsing outer yellow circle with cross ticks */}
            <div className="relative w-16 h-16 rounded-full border-2 border-[#FFDE00] shadow-[0_0_12px_rgba(255,222,0,0.6)] animate-in zoom-in-75 duration-200">
              <div className="absolute top-0 left-1/2 -translate-x-1/2 -translate-y-1 w-0.5 h-1.5 bg-[#FFDE00]" />
              <div className="absolute bottom-0 left-1/2 -translate-x-1/2 translate-y-1 w-0.5 h-1.5 bg-[#FFDE00]" />
              <div className="absolute left-0 top-1/2 -translate-y-1/2 -translate-x-1 w-1.5 h-0.5 bg-[#FFDE00]" />
              <div className="absolute right-0 top-1/2 -translate-y-1/2 translate-x-1 w-1.5 h-0.5 bg-[#FFDE00]" />
            </div>

            {/* Sun exposure adjustment handle */}
            <div
              className="absolute -right-7 top-1/2 -translate-y-1/2 pointer-events-auto flex flex-col items-center gap-1 bg-black/60 backdrop-blur-md p-1 rounded-full border border-white/20"
              onClick={(e) => e.stopPropagation()}
            >
              <button
                onClick={() => handleExposureChange(0.5)}
                className="w-5 h-5 flex items-center justify-center text-[#FFDE00] hover:scale-110 active:scale-95"
              >
                +
              </button>
              <Sun className="w-3.5 h-3.5 text-[#FFDE00]" />
              <button
                onClick={() => handleExposureChange(-0.5)}
                className="w-5 h-5 flex items-center justify-center text-[#FFDE00] hover:scale-110 active:scale-95"
              >
                -
              </button>
            </div>
          </div>
        )}

        {/* Scene Optimizer AI Badge (Samsung signature bottom-right badge) */}
        {sceneOptimizer && (
          <div className="absolute bottom-3 right-3 z-20 flex items-center gap-1.5 px-2.5 py-1 bg-black/60 backdrop-blur-md rounded-full border border-white/10 text-white/90 shadow-lg">
            <Sparkles className="w-3.5 h-3.5 text-[#FFDE00] animate-spin-slow" />
            <span className="text-[10px] font-semibold uppercase tracking-wider text-zinc-300">
              {detectedScene}
            </span>
          </div>
        )}
      </div>

      {/* LENS ZOOM TOGGLES (0.6x, 1x, 2x) — SIGNATURE SAMSUNG ONE UI ZOOM DOCK */}
      <div className="relative mt-2.5 z-20 flex flex-col items-center">
        {/* Main 0.6x / 1x / 2x Zoom Dock */}
        <div className="flex items-center gap-1 px-1.5 py-1 bg-black/75 backdrop-blur-lg rounded-full border border-white/15 shadow-xl">
          {/* 0.6x Ultra Wide */}
          <button
            onClick={() => {
              onZoomChange(0.6);
              cameraAudio.playZoomTick();
              cameraAudio.triggerHaptic('light');
            }}
            className={`min-w-[40px] h-[34px] px-2 rounded-full text-xs font-bold transition-all duration-150 flex items-center justify-center ${
              zoom === 0.6
                ? 'bg-[#FFDE00] text-black shadow-md scale-105'
                : 'text-zinc-300 hover:text-white hover:bg-white/10'
            }`}
          >
            0.6
          </button>

          {/* 1x Wide Primary */}
          <button
            onClick={() => {
              onZoomChange(1);
              cameraAudio.playZoomTick();
              cameraAudio.triggerHaptic('light');
            }}
            className={`min-w-[40px] h-[34px] px-2 rounded-full text-xs font-bold transition-all duration-150 flex items-center justify-center ${
              zoom === 1
                ? 'bg-[#FFDE00] text-black shadow-md scale-105'
                : 'text-zinc-300 hover:text-white hover:bg-white/10'
            }`}
          >
            1
          </button>

          {/* 2x Telephoto */}
          <button
            onClick={() => {
              onZoomChange(2);
              cameraAudio.playZoomTick();
              cameraAudio.triggerHaptic('light');
            }}
            className={`min-w-[40px] h-[34px] px-2 rounded-full text-xs font-bold transition-all duration-150 flex items-center justify-center ${
              zoom === 2
                ? 'bg-[#FFDE00] text-black shadow-md scale-105'
                : 'text-zinc-300 hover:text-white hover:bg-white/10'
            }`}
          >
            2
          </button>

          {/* Expand Zoom Dock Toggle */}
          <button
            onClick={() => setIsZoomDockOpen(!isZoomDockOpen)}
            className={`w-[34px] h-[34px] rounded-full text-xs font-bold flex items-center justify-center transition-all ${
              zoom > 2 || isZoomDockOpen
                ? 'bg-[#FFDE00] text-black'
                : 'text-zinc-400 hover:text-white hover:bg-white/10'
            }`}
            title="Expand zoom scale"
          >
            {zoom > 2 ? `${zoom}x` : '···'}
          </button>
        </div>

        {/* Extended Zoom Dock (0.6x, 1x, 2x, 3x, 10x, 30x) */}
        {isZoomDockOpen && (
          <div className="absolute top-11 flex items-center gap-1 p-1 bg-black/90 backdrop-blur-xl rounded-full border border-white/20 shadow-2xl animate-in fade-in slide-in-from-top-1 duration-150">
            {([0.6, 1, 2, 3, 10, 30] as ZoomLevel[]).map((z) => (
              <button
                key={z}
                onClick={() => {
                  onZoomChange(z);
                  cameraAudio.playZoomTick();
                  cameraAudio.triggerHaptic('light');
                  if (z <= 2) setIsZoomDockOpen(false);
                }}
                className={`min-w-[36px] h-[30px] px-2 rounded-full text-[11px] font-bold transition-all ${
                  zoom === z
                    ? 'bg-[#FFDE00] text-black shadow-sm'
                    : 'text-zinc-300 hover:text-white hover:bg-white/10'
                }`}
              >
                {z}x
              </button>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
