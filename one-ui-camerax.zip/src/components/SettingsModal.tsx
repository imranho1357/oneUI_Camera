import React from 'react';
import { ArrowLeft, Check } from 'lucide-react';
import { CameraSettings } from '../types/camera';
import { cameraAudio } from '../utils/audioEffects';

interface SettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  settings: CameraSettings;
  onUpdateSettings: (newSettings: Partial<CameraSettings>) => void;
}

export const SettingsModal: React.FC<SettingsModalProps> = ({
  isOpen,
  onClose,
  settings,
  onUpdateSettings,
}) => {
  if (!isOpen) return null;

  const toggle = (key: keyof CameraSettings) => {
    cameraAudio.triggerHaptic('light');
    cameraAudio.playZoomTick();
    onUpdateSettings({ [key]: !settings[key] });
  };

  return (
    <div className="fixed inset-0 z-50 bg-black text-white flex flex-col animate-in slide-in-from-bottom duration-200 select-none">
      {/* One UI Large Header */}
      <div className="pt-4 pb-4 px-6 border-b border-zinc-900 bg-zinc-950/80 backdrop-blur-md sticky top-0 z-10">
        <div className="flex items-center gap-4">
          <button
            onClick={() => {
              cameraAudio.triggerHaptic('light');
              onClose();
            }}
            className="w-10 h-10 -ml-2 rounded-full flex items-center justify-center hover:bg-white/10 active:scale-95"
          >
            <ArrowLeft className="w-6 h-6 text-white" />
          </button>
          <div>
            <h1 className="text-xl font-bold tracking-tight">Camera settings</h1>
            <p className="text-xs text-zinc-400">One UI & CameraX configuration</p>
          </div>
        </div>
      </div>

      {/* Settings Body with Samsung Groupings */}
      <div className="flex-1 overflow-y-auto px-6 py-4 space-y-6">
        {/* Section 1: Intelligent Features */}
        <div>
          <h2 className="text-xs font-bold uppercase tracking-wider text-[#FFDE00] mb-3">
            Intelligent features
          </h2>
          <div className="space-y-3 bg-zinc-900/60 rounded-2xl p-4 border border-white/5">
            <div className="flex items-center justify-between">
              <div>
                <span className="font-semibold text-sm block">Scene optimiser</span>
                <span className="text-xs text-zinc-400">
                  Automatically adjust camera settings using AI scene recognition
                </span>
              </div>
              <input
                type="checkbox"
                checked={settings.sceneOptimizer}
                onChange={() => toggle('sceneOptimizer')}
                className="w-5 h-5 accent-[#FFDE00] cursor-pointer"
              />
            </div>

            <div className="border-t border-white/5 pt-3 flex items-center justify-between">
              <div>
                <span className="font-semibold text-sm block">Scan QR codes</span>
                <span className="text-xs text-zinc-400">
                  Detect and scan QR codes automatically in viewfinder
                </span>
              </div>
              <input
                type="checkbox"
                checked={settings.scanQrCodes}
                onChange={() => toggle('scanQrCodes')}
                className="w-5 h-5 accent-[#FFDE00] cursor-pointer"
              />
            </div>
          </div>
        </div>

        {/* Section 2: Pictures & Shutter */}
        <div>
          <h2 className="text-xs font-bold uppercase tracking-wider text-[#FFDE00] mb-3">
            Pictures & Shutter
          </h2>
          <div className="space-y-3 bg-zinc-900/60 rounded-2xl p-4 border border-white/5">
            <div className="flex items-center justify-between">
              <div>
                <span className="font-semibold text-sm block">Swipe Shutter button to</span>
                <span className="text-xs text-zinc-400">
                  {settings.swipeShutterAction === 'burst' ? 'Take burst shot' : 'Create GIF'}
                </span>
              </div>
              <button
                onClick={() => {
                  cameraAudio.playZoomTick();
                  onUpdateSettings({
                    swipeShutterAction:
                      settings.swipeShutterAction === 'burst' ? 'gif' : 'burst',
                  });
                }}
                className="text-xs px-3 py-1.5 rounded-lg bg-zinc-800 text-zinc-200 border border-white/10"
              >
                {settings.swipeShutterAction === 'burst' ? 'Burst' : 'GIF'}
              </button>
            </div>

            <div className="border-t border-white/5 pt-3 flex items-center justify-between">
              <div>
                <span className="font-semibold text-sm block">Watermark</span>
                <span className="text-xs text-zinc-400">
                  Add date, model, and CameraX signature
                </span>
              </div>
              <input
                type="checkbox"
                checked={settings.watermark}
                onChange={() => toggle('watermark')}
                className="w-5 h-5 accent-[#FFDE00] cursor-pointer"
              />
            </div>
          </div>
        </div>

        {/* Section 3: General & Viewfinder */}
        <div>
          <h2 className="text-xs font-bold uppercase tracking-wider text-[#FFDE00] mb-3">
            General
          </h2>
          <div className="space-y-3 bg-zinc-900/60 rounded-2xl p-4 border border-white/5">
            <div className="flex items-center justify-between">
              <div>
                <span className="font-semibold text-sm block">Grid lines</span>
                <span className="text-xs text-zinc-400">
                  3×3 rule-of-thirds grid guides
                </span>
              </div>
              <input
                type="checkbox"
                checked={settings.gridLines}
                onChange={() => toggle('gridLines')}
                className="w-5 h-5 accent-[#FFDE00] cursor-pointer"
              />
            </div>

            <div className="border-t border-white/5 pt-3 flex items-center justify-between">
              <div>
                <span className="font-semibold text-sm block">Shutter sound</span>
                <span className="text-xs text-zinc-400">
                  Play realistic mechanical shutter and timer chimes
                </span>
              </div>
              <input
                type="checkbox"
                checked={settings.shutterSound}
                onChange={() => {
                  cameraAudio.setSoundEnabled(!settings.shutterSound);
                  toggle('shutterSound');
                }}
                className="w-5 h-5 accent-[#FFDE00] cursor-pointer"
              />
            </div>

            <div className="border-t border-white/5 pt-3 flex items-center justify-between">
              <div>
                <span className="font-semibold text-sm block">Video stabilisation (EIS)</span>
                <span className="text-xs text-zinc-400">
                  Smooth out shaky hand movement during video capture
                </span>
              </div>
              <input
                type="checkbox"
                checked={settings.stabilization}
                onChange={() => toggle('stabilization')}
                className="w-5 h-5 accent-[#FFDE00] cursor-pointer"
              />
            </div>
          </div>
        </div>

        {/* Section 4: CameraX Jetpack Engine */}
        <div>
          <h2 className="text-xs font-bold uppercase tracking-wider text-emerald-400 mb-3">
            Android CameraX Engine Config
          </h2>
          <div className="space-y-3 bg-emerald-950/20 rounded-2xl p-4 border border-emerald-500/20">
            <div className="flex items-center justify-between">
              <div>
                <span className="font-semibold text-sm block text-emerald-200">
                  Zero-Shutter Lag (ZSL)
                </span>
                <span className="text-xs text-emerald-400/80">
                  Capture frames immediately from ring buffer (`ImageCapture.CAPTURE_MODE_ZERO_SHUTTER_LAG`)
                </span>
              </div>
              <input
                type="checkbox"
                checked={settings.zeroShutterLag}
                onChange={() => toggle('zeroShutterLag')}
                className="w-5 h-5 accent-emerald-400 cursor-pointer"
              />
            </div>

            <div className="border-t border-emerald-500/15 pt-3 flex items-center justify-between">
              <div>
                <span className="font-semibold text-sm block text-emerald-200">
                  High Efficiency Video (HEVC / H.265)
                </span>
                <span className="text-xs text-emerald-400/80">
                  Recorder.Builder() with VideoSpec.QUALITY_FHD
                </span>
              </div>
              <input
                type="checkbox"
                checked={settings.highEfficiencyVideo}
                onChange={() => toggle('highEfficiencyVideo')}
                className="w-5 h-5 accent-emerald-400 cursor-pointer"
              />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
