import React, { useState } from 'react';
import {
  Settings,
  Zap,
  ZapOff,
  Clock,
  Ratio,
  Sliders,
  Code2,
  Sparkles,
} from 'lucide-react';
import { FlashMode, TimerDuration, AspectRatio, FilterType } from '../types/camera';
import { cameraAudio } from '../utils/audioEffects';

interface TopBarProps {
  flash: FlashMode;
  onFlashChange: (mode: FlashMode) => void;
  timer: TimerDuration;
  onTimerChange: (timer: TimerDuration) => void;
  aspectRatio: AspectRatio;
  onAspectRatioChange: (ratio: AspectRatio) => void;
  motionPhoto: boolean;
  onToggleMotionPhoto: () => void;
  filter: FilterType;
  onFilterChange: (filter: FilterType) => void;
  onOpenSettings: () => void;
  onOpenInspector: () => void;
}

export const TopBar: React.FC<TopBarProps> = ({
  flash,
  onFlashChange,
  timer,
  onTimerChange,
  aspectRatio,
  onAspectRatioChange,
  motionPhoto,
  onToggleMotionPhoto,
  filter,
  onFilterChange,
  onOpenSettings,
  onOpenInspector,
}) => {
  const [activeDropdown, setActiveDropdown] = useState<'flash' | 'timer' | 'ratio' | 'filter' | null>(null);

  const toggleDropdown = (menu: 'flash' | 'timer' | 'ratio' | 'filter') => {
    cameraAudio.playZoomTick();
    cameraAudio.triggerHaptic('light');
    setActiveDropdown(prev => (prev === menu ? null : menu));
  };

  return (
    <div className="w-full max-w-md px-4 pt-3 pb-1 z-30 select-none">
      {/* Top Main Icons Row */}
      <div className="flex items-center justify-between text-white/90">
        {/* Settings Button */}
        <button
          onClick={() => {
            cameraAudio.playZoomTick();
            onOpenSettings();
          }}
          className="w-10 h-10 flex items-center justify-center rounded-full hover:bg-white/10 active:scale-90 transition-all"
          title="Camera Settings"
        >
          <Settings className="w-5 h-5 text-white/90" />
        </button>

        {/* Flash Toggle */}
        <div className="relative">
          <button
            onClick={() => toggleDropdown('flash')}
            className={`w-10 h-10 flex items-center justify-center rounded-full transition-all active:scale-90 ${
              flash !== 'off' ? 'text-[#FFDE00]' : 'text-white/90 hover:bg-white/10'
            }`}
            title="Flash Mode"
          >
            {flash === 'off' ? (
              <ZapOff className="w-5 h-5" />
            ) : (
              <Zap className="w-5 h-5 fill-current" />
            )}
          </button>

          {/* Flash Dropdown */}
          {activeDropdown === 'flash' && (
            <div className="absolute top-12 -left-6 z-40 flex items-center gap-1.5 p-1.5 bg-black/85 backdrop-blur-xl rounded-full border border-white/15 shadow-2xl animate-in fade-in zoom-in-95">
              {(['off', 'auto', 'on'] as FlashMode[]).map((m) => (
                <button
                  key={m}
                  onClick={() => {
                    onFlashChange(m);
                    setActiveDropdown(null);
                  }}
                  className={`px-3 py-1 rounded-full text-xs font-semibold uppercase tracking-wider transition-all ${
                    flash === m
                      ? 'bg-[#FFDE00] text-black font-bold'
                      : 'text-zinc-300 hover:text-white'
                  }`}
                >
                  {m}
                </button>
              ))}
            </div>
          )}
        </div>

        {/* Timer Toggle */}
        <div className="relative">
          <button
            onClick={() => toggleDropdown('timer')}
            className={`w-10 h-10 flex items-center justify-center rounded-full transition-all active:scale-90 ${
              timer > 0 ? 'text-[#FFDE00]' : 'text-white/90 hover:bg-white/10'
            }`}
            title="Self Timer"
          >
            <div className="relative flex items-center justify-center">
              <Clock className="w-5 h-5" />
              {timer > 0 && (
                <span className="absolute -top-1 -right-1 text-[9px] font-bold bg-[#FFDE00] text-black px-1 rounded-full leading-tight">
                  {timer}
                </span>
              )}
            </div>
          </button>

          {/* Timer Dropdown */}
          {activeDropdown === 'timer' && (
            <div className="absolute top-12 -left-10 z-40 flex items-center gap-1.5 p-1.5 bg-black/85 backdrop-blur-xl rounded-full border border-white/15 shadow-2xl animate-in fade-in zoom-in-95">
              {([0, 2, 5, 10] as TimerDuration[]).map((t) => (
                <button
                  key={t}
                  onClick={() => {
                    onTimerChange(t);
                    setActiveDropdown(null);
                  }}
                  className={`px-2.5 py-1 rounded-full text-xs font-semibold transition-all ${
                    timer === t
                      ? 'bg-[#FFDE00] text-black font-bold'
                      : 'text-zinc-300 hover:text-white'
                  }`}
                >
                  {t === 0 ? 'Off' : `${t}s`}
                </button>
              ))}
            </div>
          )}
        </div>

        {/* Aspect Ratio */}
        <div className="relative">
          <button
            onClick={() => toggleDropdown('ratio')}
            className="h-10 px-2.5 flex items-center justify-center rounded-full text-xs font-bold tracking-tight text-white/90 hover:bg-white/10 active:scale-90 transition-all"
            title="Aspect Ratio"
          >
            <span className="border border-white/30 px-1.5 py-0.5 rounded text-[11px]">
              {aspectRatio}
            </span>
          </button>

          {/* Aspect Ratio Dropdown */}
          {activeDropdown === 'ratio' && (
            <div className="absolute top-12 -left-12 z-40 flex items-center gap-1.5 p-1.5 bg-black/85 backdrop-blur-xl rounded-full border border-white/15 shadow-2xl animate-in fade-in zoom-in-95">
              {(['3:4', '9:16', '1:1', 'full'] as AspectRatio[]).map((r) => (
                <button
                  key={r}
                  onClick={() => {
                    onAspectRatioChange(r);
                    setActiveDropdown(null);
                  }}
                  className={`px-2.5 py-1 rounded-full text-xs font-semibold uppercase tracking-wider transition-all ${
                    aspectRatio === r
                      ? 'bg-[#FFDE00] text-black font-bold'
                      : 'text-zinc-300 hover:text-white'
                  }`}
                >
                  {r}
                </button>
              ))}
            </div>
          )}
        </div>

        {/* Filter Effects */}
        <div className="relative">
          <button
            onClick={() => toggleDropdown('filter')}
            className={`w-10 h-10 flex items-center justify-center rounded-full transition-all active:scale-90 ${
              filter !== 'original' ? 'text-[#FFDE00]' : 'text-white/90 hover:bg-white/10'
            }`}
            title="Filters & Effects"
          >
            <Sliders className="w-5 h-5" />
          </button>

          {/* Filter Dropdown */}
          {activeDropdown === 'filter' && (
            <div className="absolute top-12 -right-8 z-40 flex items-center gap-1.5 p-1.5 bg-black/90 backdrop-blur-xl rounded-full border border-white/15 shadow-2xl animate-in fade-in zoom-in-95 max-w-[280px] overflow-x-auto no-scrollbar">
              {(['original', 'warm', 'cool', 'vivid', 'mono', 'film', 'vintage', 'noir'] as FilterType[]).map((f) => (
                <button
                  key={f}
                  onClick={() => {
                    onFilterChange(f);
                    setActiveDropdown(null);
                  }}
                  className={`px-2.5 py-1 rounded-full text-xs font-semibold capitalize whitespace-nowrap transition-all ${
                    filter === f
                      ? 'bg-[#FFDE00] text-black font-bold'
                      : 'text-zinc-300 hover:text-white'
                  }`}
                >
                  {f}
                </button>
              ))}
            </div>
          )}
        </div>

        {/* Native Android CameraX Code Inspector Trigger */}
        <button
          onClick={() => {
            cameraAudio.playZoomTick();
            onOpenInspector();
          }}
          className="flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-emerald-500/20 border border-emerald-500/40 text-emerald-400 text-[11px] font-bold tracking-tight hover:bg-emerald-500/30 active:scale-95 transition-all shadow-sm"
          title="Inspect Native Android CameraX Code & Architecture"
        >
          <Code2 className="w-3.5 h-3.5" />
          <span>CameraX</span>
        </button>
      </div>
    </div>
  );
};
