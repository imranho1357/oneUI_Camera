import React, { useRef, useEffect } from 'react';
import { CameraMode } from '../types/camera';
import { cameraAudio } from '../utils/audioEffects';

interface ModeSelectorProps {
  currentMode: CameraMode;
  onSelectMode: (mode: CameraMode) => void;
  disabled?: boolean;
}

interface ModeItem {
  id: CameraMode;
  label: string;
}

const MODES: ModeItem[] = [
  { id: 'portrait', label: 'PORTRAIT' },
  { id: 'photo', label: 'PHOTO' },
  { id: 'video', label: 'VIDEO' },
  { id: 'night', label: 'NIGHT' },
  { id: 'pro', label: 'PRO' },
  { id: 'more', label: 'MORE' },
];

export const ModeSelector: React.FC<ModeSelectorProps> = ({
  currentMode,
  onSelectMode,
  disabled = false,
}) => {
  const containerRef = useRef<HTMLDivElement | null>(null);
  const activeBtnRef = useRef<HTMLButtonElement | null>(null);

  // Auto scroll active item into center view
  useEffect(() => {
    if (activeBtnRef.current && containerRef.current) {
      const container = containerRef.current;
      const btn = activeBtnRef.current;
      const scrollTarget =
        btn.offsetLeft - container.clientWidth / 2 + btn.clientWidth / 2;

      container.scrollTo({
        left: scrollTarget,
        behavior: 'smooth',
      });
    }
  }, [currentMode]);

  const handleModeClick = (mode: CameraMode) => {
    if (disabled || mode === currentMode) return;
    cameraAudio.playZoomTick();
    cameraAudio.triggerHaptic('light');
    onSelectMode(mode);
  };

  return (
    <div className="w-full relative py-2 overflow-hidden flex items-center justify-center select-none">
      {/* Subtle edge fade gradient */}
      <div className="absolute left-0 inset-y-0 w-12 bg-gradient-to-r from-black to-transparent pointer-events-none z-10" />
      <div className="absolute right-0 inset-y-0 w-12 bg-gradient-to-l from-black to-transparent pointer-events-none z-10" />

      {/* Horizontal Slider Text Row */}
      <div
        ref={containerRef}
        className="flex items-center gap-6 sm:gap-8 px-16 overflow-x-auto no-scrollbar scroll-smooth snap-x snap-mandatory py-1"
        style={{ scrollbarWidth: 'none', msOverflowStyle: 'none' }}
      >
        {MODES.map((m) => {
          const isActive = currentMode === m.id;
          return (
            <button
              key={m.id}
              ref={isActive ? activeBtnRef : null}
              disabled={disabled}
              onClick={() => handleModeClick(m.id)}
              className={`snap-center shrink-0 flex flex-col items-center justify-center group focus:outline-none transition-all duration-200 cursor-pointer disabled:opacity-50 ${
                isActive ? 'scale-105' : 'hover:opacity-80'
              }`}
            >
              <span
                className={`text-xs sm:text-sm tracking-wider font-semibold transition-colors duration-150 ${
                  isActive
                    ? 'text-[#FFDE00] font-bold drop-shadow-[0_0_8px_rgba(255,222,0,0.4)]'
                    : 'text-zinc-400 group-hover:text-zinc-200'
                }`}
              >
                {m.label}
              </span>

              {/* Samsung Yellow Active Dot */}
              <span
                className={`w-1.5 h-1.5 rounded-full mt-1 transition-all duration-200 ${
                  isActive
                    ? 'bg-[#FFDE00] shadow-[0_0_6px_#FFDE00] opacity-100 scale-100'
                    : 'bg-transparent opacity-0 scale-50'
                }`}
              />
            </button>
          );
        })}
      </div>
    </div>
  );
};
