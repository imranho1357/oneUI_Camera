export type CameraMode = 'portrait' | 'photo' | 'video' | 'pro' | 'night' | 'more';

export type ZoomLevel = 0.6 | 1 | 2 | 3 | 10 | 30;

export type AspectRatio = '3:4' | '9:16' | '1:1' | 'full';

export type FlashMode = 'off' | 'auto' | 'on' | 'torch';

export type TimerDuration = 0 | 2 | 5 | 10;

export type FilterType = 'original' | 'warm' | 'cool' | 'vivid' | 'mono' | 'film' | 'vintage' | 'noir';

export type PortraitEffect = 'natural' | 'studio' | 'high_key_mono' | 'low_key_mono' | 'color_point' | 'backdrop';

export interface CapturedMedia {
  id: string;
  type: 'photo' | 'video';
  url: string;
  thumbnailUrl: string;
  timestamp: number;
  duration?: number; // for video in seconds
  metadata: {
    width: number;
    height: number;
    mode: CameraMode;
    zoom: number;
    flash: FlashMode;
    filter: FilterType;
    iso: number;
    shutterSpeed: string;
    focalLength: string;
    lensFacing: 'back' | 'front';
    aspectRatio: AspectRatio;
  };
}

export interface CameraSettings {
  sceneOptimizer: boolean;
  scanQrCodes: boolean;
  gridLines: boolean;
  watermark: boolean;
  watermarkText: string;
  shutterSound: boolean;
  highEfficiencyVideo: boolean;
  zeroShutterLag: boolean;
  swipeShutterAction: 'burst' | 'gif';
  stabilization: boolean;
}

export interface CameraXTelemetry {
  targetAspectRatio: string;
  resolution: string;
  lensFacing: 'LENS_FACING_BACK' | 'LENS_FACING_FRONT';
  flashMode: 'FLASH_MODE_OFF' | 'FLASH_MODE_AUTO' | 'FLASH_MODE_ON';
  torchState: 'TORCH_OFF' | 'TORCH_ON';
  zoomRatio: number;
  minZoomRatio: number;
  maxZoomRatio: number;
  previewState: 'STREAMING' | 'IDLE';
  activeUseCases: string[];
  fps: number;
}
